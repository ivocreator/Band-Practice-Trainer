// Verify musical measure arithmetic and the exact judgment boundaries.
import test from 'node:test';
import assert from 'node:assert/strict';
import {LEVELS,makeMeasure,classify} from '../dist/rhythms.js';
test('every pattern fills its measure with non-overlapping onsets',()=>{
 for(const l of LEVELS)for(let i=0;i<l.patterns.length;i++){
  const notes=makeMeasure(l,i);assert.ok(Math.abs(notes.reduce((s,n)=>s+n.duration,0)-l.bar)<1e-9);
  for(let j=1;j<notes.length;j++)assert.ok(notes[j].beat>notes[j-1].beat);
 }
});
test('timing boundaries preserve sign',()=>{
 for(const [error,result] of [[0,'Perfect'],[-30,'Perfect'],[31,'Good'],[70,'Good'],[-71,'Early'],[71,'Late'],[150,'Late'],[-151,'Miss']])assert.equal(classify(error),result);
});
test('6/8 has two dotted-quarter pulses and six eighth subdivisions',()=>{
 const l=LEVELS.at(-1);assert.equal(l.bar/l.pulse,2);assert.equal(l.bar/l.sub,6);
});
