-- Run once in the Supabase SQL Editor. Each browser signs in anonymously.
create table if not exists public.rhythm_results (
 id uuid primary key,
 user_id uuid not null references auth.users(id) on delete cascade,
 date timestamptz not null default now(),
 rhythm_type text not null,
 tempo integer not null check (tempo between 40 and 180),
 -- Mean absolute error in milliseconds, excluding misses. NULL = no matched taps.
 average_timing_error double precision check (average_timing_error >= 0),
 signed_timing_error double precision,
 note_count integer not null check (note_count > 0),
 miss_count integer not null check (miss_count >= 0),
 extra_taps integer not null check (extra_taps >= 0),
 mode text not null check (mode in ('round','practice'))
);
alter table public.rhythm_results enable row level security;
revoke all on public.rhythm_results from anon;
grant select, insert on public.rhythm_results to authenticated;
create policy "Students insert their own results" on public.rhythm_results
 for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Students read their own results" on public.rhythm_results
 for select to authenticated using ((select auth.uid()) = user_id);
-- No UPDATE or DELETE policies: client code cannot alter prior results.
