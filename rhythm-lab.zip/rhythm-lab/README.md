# Rhythm Lab — beginner band rhythm game

All source files are included in full, with comments. No build step or paid library is required.

## Run it on your computer

1. Download and extract the ZIP. Keep the files together.
2. Install Python 3 from https://www.python.org/downloads/ if you do not already have it. On Windows, select “Add Python to PATH.”
3. Open a terminal in the extracted `rhythm-lab` folder. On Windows, open the folder in File Explorer, click the address bar, type `cmd`, and press Enter.
4. Run `python -m http.server 8000 --directory dist`. On macOS, you may need `python3` instead of `python`.
5. Open http://localhost:8000 in Chrome, Edge, Firefox, or Safari. Leave the terminal running. Press Ctrl+C in the terminal to stop the server.

Do not just double-click index.html: JavaScript modules need a web server. No npm install is needed to play. A phone can use the hosted version; local audio features require localhost or HTTPS.

## Play

Choose a level, set 40–180 BPM, and press Start round. Listen through one measure of count-in. Notes move toward the gold hit line. Tap Space or the large Tap rhythm button when each note begins. Pointer-down responds immediately to clicks or touches. Do not hold long notes or tap rests. Repeated keydown events are ignored.

Each round contains four measures. Practice mode repeats the first measure of the chosen level until Finish / stop. Controls lock during play so tempo cannot change the active timeline. Moving to another tab ends the round and reports only elapsed onsets.

In 4/4 and 3/4, BPM means quarter notes. In 6/8, BPM means dotted quarters: two main pulses per measure. The metronome also sounds quieter eighth subdivisions for 6/8. Strong clicks mark bar beginnings. Count-in always sounds even if the round metronome is unchecked.

Perfect is within 30 ms, Good within 70 ms, Early/Late within 150 ms, and unmatched onsets are Misses. At high tempos, dense notes have a matching window smaller than 150 ms (48% of the nearest onset gap) so one tap does not claim a neighboring note. Extra taps are counted separately. Rests are silent; tapping during a rest is an extra tap unless it legitimately matches a nearby note's onset window.

The report graph shows signed milliseconds by note order. Negative = early; positive = late. Misses are × symbols. Average timing error is the mean absolute error of matched taps only; misses and extra taps remain separate so an empty performance cannot appear as 0 ms accuracy. A round with no matched taps saves NULL for average error.

## Calibrate

Press Calibrate timing, then Begin calibration. Listen to four warm-up clicks, then tap with the next twelve clicks at 100 BPM. At least six usable taps are required. The median error becomes the stored offset. Positive offsets are subtracted from input times and used to align the visual lane. Use the same input method and headphones afterward; recalibrate after changing equipment. This measures combined output/input delay and your tapping response, rather than isolating hardware latency. Natural timing bias can influence it.

## Connect Supabase

1. Create a project at https://supabase.com.
2. Open its SQL Editor. Paste the complete contents of `supabase.sql` and run it once.
3. In Authentication settings, enable anonymous sign-ins. Supabase anonymous users are authenticated identities, so each browser can insert and read only rows with its own user ID.
4. Copy your Project URL and **publishable key** (or legacy anon key) from the project API settings. Never use a secret or service-role key in this browser app.
5. Open “Connect Supabase” in the game, paste those values, and press Save connection. Pending results upload automatically. Later rounds save automatically. Use Retry saving results if your connection fails.
6. Inspect `rhythm_results` in the Table Editor. Columns include date, rhythm_type, tempo, average_timing_error (milliseconds), signed_timing_error, note_count, miss_count, extra_taps, and mode.

The app uses Supabase Auth and REST through fetch, with no CDN dependency. Anonymous sessions and results stay in this browser's local storage. Clearing browser data loses this device's identity and local queue. Previously uploaded rows remain in Supabase. Requests use a UUID and ignore-duplicates so retrying does not create duplicate rows. No real student names or email addresses are collected. For a public classroom deployment, configure Supabase's anonymous sign-in abuse controls/rate limits.

Without configured credentials, the game saves locally and labels the result accordingly. Failed uploads remain queued and display an error. Cloud writes cannot be verified until a real project is connected.

## How the code works

- `dist/index.html`: semantic page, settings, canvas, report, and calibration dialog.
- `dist/styles.css`: responsive studio layout and focus styles.
- `dist/rhythms.js`: eight levels, musical durations, and judgment thresholds.
- `dist/app.js`: audio scheduling, scrolling, input matching, calibration, and reports.
- `dist/storage.js`: local persistence, anonymous authentication, and Supabase uploads.
- `supabase.sql`: table and row-level security policies.
- `tests/rhythm.test.js`: musical arithmetic and timing boundary tests.
- `package.json`: optional test command; not needed to run the game.

The Web Audio API `currentTime` is the musical clock. Oscillator clicks are scheduled ahead with oscillator.start(time). requestAnimationFrame replenishes a 200 ms look-ahead queue and renders notes; no setTimeout controls musical timing. Input event timestamps are mapped to the audio clock to account for event dispatch delay. A background tab is stopped to avoid false misses. Severe foreground main-thread stalls can still disrupt the scheduling queue; browser timing is not a laboratory measurement.

To run automated unit checks, install Node.js and run `npm test` from the project folder. No npm install is required.

## Extend it for your engineering portfolio

Add new patterns in rhythms.js, ensuring each measure sums to its bar length. Explain your timing decisions, test results, and calibration limitations in your project write-up. You can compare performance at different tempos using the saved table. Build on the project and be clear about which parts you wrote or adapted.
