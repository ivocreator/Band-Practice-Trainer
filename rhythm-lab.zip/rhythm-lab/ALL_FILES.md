# Complete source files

Every file is reproduced below without omissions.

## dist/index.html

````html
<!doctype html>
<html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Rhythm Lab · Band practice</title><link rel="stylesheet" href="styles.css"></head>
<body><main>
<header><a class="brand" href="./">◷ RHYTHM LAB</a><span>BEGINNING BAND / TIMING STUDIO</span></header>
<section class="intro"><div><p class="eyebrow">LISTEN. COUNT. PLAY.</p><h1>Find your rhythm.</h1><p>Tap once at each note’s beginning. Stay silent for rests.</p></div><button id="calibrate">Calibrate timing</button></section>
<section class="controls" aria-label="Practice settings"><label>LEVEL<select id="level"></select></label><label class="tempo">TEMPO <output id="bpm">80 BPM</output><input id="tempo" type="range" min="40" max="180" value="80"></label><label>ROUND MODE<select id="mode"><option value="round">4 measures</option><option value="practice">Loop one rhythm</option></select></label><label class="check"><input id="metro" type="checkbox" checked> Metronome</label></section>
<section class="studio"><div class="studio-top"><span id="meter">4/4</span><span id="phase" role="status">Ready when you are</span><span id="offset">Offset: 0 ms</span></div><canvas id="lane" aria-label="Scrolling rhythm. Notes move right to left toward the gold hit line."></canvas><div class="feedback"><strong id="judgment" aria-live="polite">SPACE TO PLAY</strong><span id="detail">A one-measure count-in gives you the beat.</span></div><div class="transport"><button id="start" class="primary">Start round</button><button id="stop" disabled>Finish / stop</button><button id="tap" class="tap" disabled>Tap rhythm <kbd>SPACE</kbd></button></div></section>
<section class="below"><article><p class="eyebrow">YOUR RHYTHM</p><h2 id="lesson"></h2><p id="tip"></p><div id="pattern" class="pattern"></div><p class="small">Outline notes = upcoming · filled gold = hit · red = missed · gray R = rest. Tap onsets only; you don’t need to hold long notes.</p></article><article><p class="eyebrow">TIMING WINDOWS</p><div class="windows"><span><b>Perfect</b> ±30 ms</span><span><b>Good</b> ±70 ms</span><span><b>Early / Late</b> ±150 ms</span><span><b>Miss</b> outside window</span></div><p class="small">Negative error means early. Positive means late. Dense notes use a smaller matching window to keep adjacent taps separate.</p></article></section>
<section id="results" hidden><p class="eyebrow">ROUND REPORT</p><h2>Your timing, note by note.</h2><div id="stats" class="stats"></div><canvas id="graph" aria-label="Timing error graph"></canvas><p id="graphText"></p><p id="saveStatus" role="status"></p><button id="retry">Retry saving results</button></section>
<details class="connection"><summary>Connect Supabase</summary><p>Run supabase.sql, enable anonymous sign-ins, then enter your project URL and publishable key. No student names are collected.</p><label>Project URL<input id="url" type="url" placeholder="https://your-project.supabase.co"></label><label>Publishable / anon key<input id="key" type="password" autocomplete="off"></label><button id="connect">Save connection</button><p id="connectionStatus" role="status"></p></details>
<footer>Made for steady progress. Headphones recommended. <span id="storageStatus"></span></footer>
</main>
<dialog id="calibration"><h2>Calibrate your setup</h2><p>Listen for 4 warm-up clicks, then tap with the next 12 clicks. Your median timing offset compensates for this device and your response.</p><p id="calStatus" role="status">Use the same headphones and input method you’ll practice with.</p><button id="calStart" class="primary">Begin calibration</button><button id="calTap" disabled>Tap with click</button><button id="calReset">Reset offset</button><button id="calClose">Close</button></dialog>
<!-- All game code is local; cloud saving uses fetch rather than a CDN dependency. -->
<script type="module" src="app.js"></script></body></html>

````

## dist/styles.css

````css
/* A dark rehearsal studio with bright, readable timing cues. */
:root{color-scheme:dark;--bg:#101a24;--panel:#182735;--ink:#edf4f6;--muted:#a8bdc9;--gold:#f9cc65;--mint:#8ce3c3;--red:#ff8d93}*{box-sizing:border-box}body{margin:0;background:var(--bg);color:var(--ink);font:16px/1.5 system-ui,sans-serif}main{max-width:1160px;margin:auto;padding:28px}header{display:flex;justify-content:space-between;border-bottom:1px solid #354553;padding-bottom:20px;gap:20px}header span,.eyebrow{font-size:12px;letter-spacing:2px;color:var(--muted)}.brand{color:var(--gold);font-weight:800;letter-spacing:2px;text-decoration:none}.intro{display:flex;align-items:center;justify-content:space-between;gap:20px;padding:25px 0}.eyebrow{margin:0 0 8px}h1{font-size:clamp(32px,5vw,52px);letter-spacing:-2px;margin:0}h2{font-size:24px;margin:4px 0 12px}p{color:var(--muted);margin:8px 0 16px}button,input,select{font:inherit}button,select,input[type=url],input[type=password]{border:1px solid #4c6475;background:#223646;color:var(--ink);border-radius:8px;padding:11px 16px}button{cursor:pointer;font-weight:650}button:hover{border-color:var(--gold)}button:disabled{opacity:.45;cursor:default}.primary{background:var(--gold);color:#18212a;border-color:var(--gold)}:focus-visible{outline:3px solid var(--mint);outline-offset:4px}.controls{display:grid;grid-template-columns:1.4fr 1.2fr 1fr auto;gap:22px;align-items:center;background:var(--panel);padding:20px;border-radius:12px 12px 0 0}label{display:flex;flex-direction:column;gap:8px;font-size:14px;color:var(--muted)}select{width:100%;font-size:16px}.tempo{position:relative}.tempo output{position:absolute;right:0;color:var(--gold)}input[type=range]{width:100%;accent-color:var(--gold)}.check{flex-direction:row;align-items:center}.studio{border:1px solid #3a4c5b;border-radius:0 0 12px 12px;overflow:hidden}.studio-top{display:flex;justify-content:space-between;padding:15px 22px;font-size:14px;color:var(--muted)}#meter{color:var(--gold);font-weight:800}canvas{display:block;width:100%}#lane{height:220px;background:#111e29}.feedback{display:flex;justify-content:space-between;align-items:center;gap:20px;padding:18px 22px;min-height:73px}#judgment{font-size:23px;color:var(--gold)}#detail{font-size:14px;color:var(--muted)}.transport{display:flex;gap:12px;padding:0 22px 22px}.tap{margin-left:auto;min-width:35%;touch-action:manipulation;background:#2c485a}kbd{margin-left:15px;color:var(--gold);font-size:12px}.below{display:grid;grid-template-columns:1.2fr 1fr;gap:40px;margin:32px 0}.small{font-size:14px}.pattern{display:flex;flex-wrap:wrap;gap:8px}.pattern span{border:1px solid #435766;border-radius:5px;padding:6px 10px;color:var(--gold)}.windows{display:grid;grid-template-columns:1fr 1fr;gap:12px}.windows span{color:var(--muted);font-size:14px}.windows b{display:block;color:var(--ink)}#results{background:var(--panel);padding:24px;border-radius:12px;margin-bottom:25px}.stats{display:flex;gap:25px;flex-wrap:wrap;margin:20px 0}.stats b{display:block;color:var(--gold);font-size:25px}#graph{height:240px}.connection{border-top:1px solid #3a4c5b;padding:20px 0}.connection label{margin:15px 0}.connection input{width:100%}summary{cursor:pointer}footer{font-size:12px;color:var(--muted);padding:20px 0}dialog{max-width:520px;border:1px solid #566d7e;border-radius:16px;background:var(--panel);color:var(--ink);padding:28px}dialog::backdrop{background:#050b13c9}dialog button{margin:5px}#calStatus{color:var(--gold)}@media(max-width:720px){main{padding:16px}header span{display:none}.intro{align-items:flex-start;flex-direction:column}.controls{grid-template-columns:1fr 1fr;gap:16px}.below{grid-template-columns:1fr;gap:18px}.feedback{flex-direction:column;align-items:flex-start;gap:3px}.transport{flex-wrap:wrap}.tap{width:100%;margin:0}.studio-top{padding:12px;font-size:12px}#lane{height:190px}}@media(prefers-reduced-motion:reduce){*{scroll-behavior:auto}}

````

## dist/rhythms.js

````javascript
// Durations are in quarter-note units. A rest still occupies musical time.
// 6/8 has three quarter units per measure, but two dotted-quarter pulses.
const n = (duration, label, rest = false) => ({ duration, label, rest });
export const LEVELS = [
 {name:'1 · Notes & rests',type:'quarter-half-whole',meter:'4/4',bar:4,pulse:1,sub:1,tip:'Count 1 2 3 4. Half notes last 2 counts; whole notes last 4. Tap only at the start.',patterns:[[n(1,'♩'),n(1,'quarter rest',true),n(2,'𝅗𝅥')],[n(4,'𝅝')],[n(2,'half rest',true),n(1,'♩'),n(1,'♩')],[n(4,'whole rest',true)]]},
 {name:'2 · Eighth notes',type:'eighth',meter:'4/4',bar:4,pulse:1,sub:1,tip:'Count 1 & 2 & 3 & 4 &. Each eighth note lasts half a beat.',patterns:[[n(.5,'♪'),n(.5,'♪'),n(1,'♩'),n(.5,'eighth rest',true),n(.5,'♪'),n(1,'♩')]]},
 {name:'3 · Sixteenth notes',type:'sixteenth',meter:'4/4',bar:4,pulse:1,sub:1,tip:'Count 1 e & a. Four sixteenth notes fit into one beat.',patterns:[[...Array.from({length:4},()=>n(.25,'♬ 16th')),n(1,'♩'),n(.5,'♪'),n(.25,'16th rest',true),n(.25,'♬ 16th'),n(1,'♩')]]},
 {name:'4 · Dotted rhythms',type:'dotted',meter:'4/4',bar:4,pulse:1,sub:1,tip:'A dot adds half the original value. Dotted quarter + eighth = 2 beats.',patterns:[[n(1.5,'♩.'),n(.5,'♪'),n(.75,'♪.'),n(.25,'♬ 16th'),n(1,'♩')]]},
 {name:'5 · Syncopation',type:'syncopation',meter:'4/4',bar:4,pulse:1,sub:1,tip:'Keep counting the beat while notes begin between beats. Long notes cross the beat without another tap.',patterns:[[n(.5,'eighth rest',true),n(1,'♩'),n(.5,'♪'),n(.5,'♪'),n(1,'♩'),n(.5,'♪')]]},
 {name:'6 · Triplets',type:'triplet',meter:'4/4',bar:4,pulse:1,sub:1,tip:'Count 1-trip-let, 2-trip-let. Each set of 3 notes takes one beat.',patterns:[[...Array.from({length:6},()=>n(1/3,'♪ ³')),n(1,'♩'),...Array.from({length:3},()=>n(1/3,'♪ ³'))]]},
 {name:'7 · Three-quarter time',type:'3/4',meter:'3/4',bar:3,pulse:1,sub:1,tip:'Count 1 2 3. The strong click marks the start of each three-beat measure.',patterns:[[n(1,'♩'),n(2,'𝅗𝅥')],[n(.5,'♪'),n(.5,'♪'),n(1,'quarter rest',true),n(1,'♩')]]},
 {name:'8 · Six-eight time',type:'6/8',meter:'6/8',bar:3,pulse:1.5,sub:.5,tip:'BPM counts dotted quarters. Count ONE la li TWO la li: two main beats, each divided into three eighth notes.',patterns:[[...Array.from({length:6},()=>n(.5,'♪'))],[n(1.5,'♩.'),n(.5,'eighth rest',true),n(.5,'♪'),n(.5,'♪')]]}
];
// One practice pattern repeats; a round cycles the available patterns over four bars.
export function makeMeasure(level, index = 0) {
 let beat = 0;
 return level.patterns[index % level.patterns.length].map(item => {
  const event = {...item, beat}; beat += item.duration; return event;
 });
}
export function classify(ms) {
 const magnitude = Math.abs(ms);
 return magnitude <= 30 ? 'Perfect' : magnitude <= 70 ? 'Good' : magnitude <= 150 ? (ms < 0 ? 'Early' : 'Late') : 'Miss';
}

````

## dist/storage.js

````javascript
// Local data keeps the game useful without a network or a Supabase project.
const read = (key, fallback) => { try { return JSON.parse(localStorage.getItem(key)) ?? fallback; } catch { return fallback; } };
export const settings = read('rhythm-settings', {offset:0,url:'',key:''});
export const records = read('rhythm-results', []);
export let localAvailable = true;
export function persist() {
 try { localStorage.setItem('rhythm-settings',JSON.stringify(settings)); localStorage.setItem('rhythm-results',JSON.stringify(records)); }
 catch { localAvailable = false; }
}
// Supabase REST/Auth endpoints avoid depending on a hosted JavaScript library.
let session = read('rhythm-session',null);
async function request(path, body, token) {
 const response = await fetch(settings.url + path, {method:'POST',headers:{apikey:settings.key,'Content-Type':'application/json',...(token ? {Authorization:`Bearer ${token}`} : {}),Prefer:'return=minimal,resolution=ignore-duplicates'},body:JSON.stringify(body)});
 if(!response.ok) throw new Error(`Supabase ${response.status}: ${await response.text()}`);
 const text = await response.text();
 return text ? JSON.parse(text) : null;
}
async function identity() {
 if(session?.url === settings.url && session.expires_at > Date.now()/1000 + 60) return session;
 let data;
 if(session?.url === settings.url && session.refresh_token) {
  try { data = await request('/auth/v1/token?grant_type=refresh_token',{refresh_token:session.refresh_token}); } catch { session = null; }
 }
 if(!data) data = await request('/auth/v1/signup',{});
 session = {...data,url:settings.url,expires_at:Date.now()/1000 + data.expires_in};
 try {localStorage.setItem('rhythm-session',JSON.stringify(session));} catch {localAvailable=false;}
 return session;
}
export async function syncResults() {
 if(!settings.url || !settings.key) return 'Saved on this device. Connect Supabase to upload results.';
 const auth = await identity();
 // Stable UUIDs and ignore-duplicates make retries safe after uncertain network failures.
 for(const record of records.filter(r=>!r.synced)) {
  await request('/rest/v1/rhythm_results?on_conflict=id', {...record.row,user_id:auth.user.id},auth.access_token);
  record.synced = true; persist();
 }
 return 'Results saved to Supabase.';
}
export function saveRecord(row) {
 records.push({row,synced:false}); persist();
}

````

## dist/app.js

````javascript
import {LEVELS, makeMeasure, classify} from './rhythms.js';
import {settings, persist, saveRecord, syncResults, localAvailable} from './storage.js';
const $ = id => document.getElementById(id);
const lane = $('lane'), pen = lane.getContext('2d');
let audio, active = null, nodes = new Set(), calibration = null;
const colors = {Perfect:'#8ce3c3',Good:'#f9cc65',Early:'#9ac5ff',Late:'#ffa873',Miss:'#ff8d93'};
// AudioContext.currentTime is the sole musical clock. rAF only replenishes a
// look-ahead queue and paints the screen; oscillator.start schedules the sound.
async function unlockAudio() {
 audio ??= new (window.AudioContext || window.webkitAudioContext)();
 await audio.resume();
 if(audio.state !== 'running') throw new Error('Audio could not start. Try again.');
}
function click(time, accent, soft = false) {
 const oscillator = audio.createOscillator(), gain = audio.createGain();
 oscillator.frequency.value = accent ? 1300 : soft ? 650 : 900;
 gain.gain.setValueAtTime(0,time);
 gain.gain.linearRampToValueAtTime(soft ? .05 : .18,time+.002);
 gain.gain.exponentialRampToValueAtTime(.001,time+.045);
 oscillator.connect(gain); gain.connect(audio.destination);
 oscillator.start(time); oscillator.stop(time+.05); nodes.add(oscillator);
 oscillator.onended=()=>{nodes.delete(oscillator);oscillator.disconnect();gain.disconnect();};
}
function silence() { for(const node of nodes) { try {node.stop();} catch {} } nodes.clear(); }
function level() { return LEVELS[Number($('level').value)]; }
function updateSettings() {
 const l=level(); $('bpm').textContent=`${$('tempo').value} BPM`;
 $('meter').textContent=l.meter; $('lesson').textContent=l.name.slice(4);
 $('tip').textContent=l.tip; $('pattern').replaceChildren();
 makeMeasure(l).forEach(e=>{const s=document.createElement('span');s.textContent=e.label;$('pattern').append(s);});
 $('offset').textContent=`Offset: ${settings.offset} ms`;
}
LEVELS.forEach((l,i)=>$('level').add(new Option(l.name,i)));
['level','tempo'].forEach(id=>$(id).addEventListener('input',updateSettings));
function lockControls(locked) {
 ['level','tempo','mode','metro','start','calibrate'].forEach(id=>$(id).disabled=locked);
 $('stop').disabled=!locked; $('tap').disabled=!locked;
}
function addBar(index) {
 const g=active, base=g.start+index*g.barSeconds;
 makeMeasure(g.level,g.practice?0:index).forEach(e=>g.events.push({...e,time:base+e.beat*g.unit,bar:index,result:null,error:null}));
 g.generated++;
}
async function start() {
 try {await unlockAudio();} catch(e) {$('phase').textContent=e.message;return;}
 silence();const l=level(), bpm=Number($('tempo').value), unit=60/bpm/l.pulse;
 const countStart=audio.currentTime+.25, barSeconds=l.bar*unit;
 active={level:l,bpm,unit,barSeconds,countStart,start:countStart+barSeconds,practice:$('mode').value==='practice',generated:0,events:[],nextClick:countStart,clickIndex:0,extras:0,offset:settings.offset,metro:$('metro').checked};
 for(let i=0;i<4;i++)addBar(i);
 $('results').hidden=true;lockControls(true);$('judgment').textContent='COUNT IN';$('detail').textContent='Listen to one full measure, then play.';
}
// Use the event's timestamp, mapped onto the audio clock, to reduce main-thread
// dispatch delay. Calibration subtracts the measured median combined offset.
function inputTime(event) {
 const stamp=event.timeStamp;
 const age=Number.isFinite(stamp) && Math.abs(performance.now()-stamp)<10000 ? Math.max(0,performance.now()-stamp)/1000 : 0;
 return audio.currentTime-age;
}
function showHit(result,error) {
 $('judgment').textContent=result; $('judgment').style.color=colors[result];
 $('detail').textContent=error===null?'No note here — keep counting.':`${error>0?'+':''}${Math.round(error)} ms ${error<0?'early':'late'}`;
}
function tap(event) {
 if(!audio)return;
 if(calibration) {calibrationTap(event);return;}
 const g=active;if(!g)return;
 const t=inputTime(event)-g.offset/1000;
 if(t<g.start-.15)return;
 const pending=g.events.filter(e=>!e.rest&&!e.result);
 let target=pending.reduce((best,e)=>!best||Math.abs(e.time-t)<Math.abs(best.time-t)?e:best,null);
 // Shrink the acceptance window for neighboring notes faster than 300 ms apart.
 const notes=g.events.filter(e=>!e.rest), index=notes.indexOf(target);
 const gap=target?Math.min(index>0?target.time-notes[index-1].time:Infinity,index<notes.length-1?notes[index+1].time-target.time:Infinity):Infinity;
 const window=Math.min(.15,gap*.48);
 if(target && Math.abs(t-target.time)<=window) {
  target.error=(t-target.time)*1000; target.result=classify(target.error);showHit(target.result,target.error);
 } else {g.extras++;showHit('Miss',null);}
}
function schedule() {
 if(calibration) {
  while(calibration.scheduled<16 && calibration.start+calibration.scheduled*.6<audio.currentTime+.2) {
   click(calibration.start+calibration.scheduled*.6,calibration.scheduled%4===0);calibration.scheduled++;
  }
  const i=Math.floor((audio.currentTime-calibration.start)/.6);
  $('calStatus').textContent=i<0?'Get ready…':i<4?`Warm-up ${i+1} / 4`: `Tap ${Math.min(12,i-3)} / 12 · ${calibration.samples.length} captured`;
  if(audio.currentTime>calibration.start+16*.6+.3)finishCalibration();
 }
 const g=active;if(!g)return;
 if(g.practice && audio.currentTime>g.start+(g.generated-2)*g.barSeconds)addBar(g.generated);
 const end=g.start+4*g.barSeconds;
 while(g.nextClick<audio.currentTime+.2 && (g.practice || g.nextClick<end-.001)) {
  const beat=g.clickIndex*g.level.sub;
  if(g.nextClick<g.start-.001 || g.metro) click(g.nextClick,Math.abs(beat%g.level.bar)<.001,g.level.meter==='6/8' && Math.abs(beat%1.5)>.001);
  g.nextClick+=g.level.sub*g.unit;g.clickIndex++;
 }
 const correctedNow=audio.currentTime-g.offset/1000;
 for(const e of g.events)if(!e.rest&&!e.result&&correctedNow>e.time+.15)e.result='Miss';
 if(audio.currentTime<g.start) {
  const pulse=Math.floor((audio.currentTime-g.countStart)/(g.level.pulse*g.unit));
  $('phase').textContent=`Count in · ${Math.max(1,pulse+1)}`;
 } else $('phase').textContent=`Measure ${Math.floor((audio.currentTime-g.start)/g.barSeconds)+1}${g.practice?' · looping':' / 4'}`;
 if(!g.practice && correctedNow>end+.2)finish(false);
}
function sizedCanvas(canvas) {
 const rect=canvas.getBoundingClientRect(), dpr=window.devicePixelRatio||1;
 if(canvas.width!==Math.round(rect.width*dpr)||canvas.height!==Math.round(rect.height*dpr)){canvas.width=Math.round(rect.width*dpr);canvas.height=Math.round(rect.height*dpr);}
 const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);return {ctx,w:rect.width,h:rect.height};
}
function drawLane() {
 const {ctx,w,h}=sizedCanvas(lane), hit=w*.2, mid=h*.5;ctx.clearRect(0,0,w,h);
 ctx.strokeStyle='#334957';ctx.lineWidth=1;
 for(let i=-2;i<=2;i++){ctx.beginPath();ctx.moveTo(0,mid+i*17);ctx.lineTo(w,mid+i*17);ctx.stroke();}
 ctx.fillStyle='#f9cc6515';ctx.fillRect(hit-14,0,28,h);ctx.strokeStyle='#f9cc65';ctx.lineWidth=2;ctx.beginPath();ctx.moveTo(hit,20);ctx.lineTo(hit,h-20);ctx.stroke();
 ctx.fillStyle='#f9cc65';ctx.font='12px system-ui';ctx.fillText('HIT',hit-10,h-12);
 const g=active;
 if(!g){ctx.fillStyle='#a8bdc9';ctx.font='16px system-ui';ctx.fillText('Start a round to bring the notes in.',Math.max(hit+25,w*.28),mid);return;}
 // A fixed 3.5-second runway gives even slow whole notes time to approach.
 const speed=(w-hit-35)/3.5, now=audio.currentTime-g.offset/1000;
 for(const e of g.events){const x=hit+(e.time-now)*speed;if(x< -150||x>w+70)continue;
  ctx.fillStyle=e.rest?'#8b9eab':e.result?colors[e.result]:'#edf4f6';ctx.strokeStyle=ctx.fillStyle;
  if(e.beat===0){ctx.strokeStyle='#4b6274';ctx.lineWidth=1;ctx.beginPath();ctx.moveTo(x,30);ctx.lineTo(x,h-35);ctx.stroke();ctx.fillStyle='#a8bdc9';ctx.font='12px system-ui';ctx.fillText(`BAR ${e.bar+1}`,x+5,25);ctx.fillStyle=e.rest?'#8b9eab':e.result?colors[e.result]:'#edf4f6';ctx.strokeStyle=ctx.fillStyle;}
  if(e.rest){ctx.font='bold 18px system-ui';ctx.fillText('R',x-7,mid+7);}
  else {ctx.lineWidth=2;ctx.beginPath();ctx.ellipse(x,mid,9,6,-.3,0,Math.PI*2);e.duration>=2&&!e.result?ctx.stroke():ctx.fill();if(e.duration<4){ctx.beginPath();ctx.moveTo(x+8,mid);ctx.lineTo(x+8,mid-35);ctx.stroke();}if(e.duration<=.75){ctx.beginPath();ctx.moveTo(x+8,mid-35);ctx.quadraticCurveTo(x+27,mid-29,x+14,mid-17);ctx.stroke();}if(e.duration<=.25){ctx.beginPath();ctx.moveTo(x+8,mid-26);ctx.lineTo(x+20,mid-15);ctx.stroke();}if([1.5,.75].includes(e.duration)){ctx.beginPath();ctx.arc(x+18,mid,2.5,0,7);ctx.fill();}}
  ctx.font='12px system-ui';ctx.fillText(e.label,x-12,mid+40);
 }
}
function graph(notes) {
 const {ctx,w,h}=sizedCanvas($('graph')), left=48,right=w-18,top=20,bottom=h-35;
 ctx.clearRect(0,0,w,h);ctx.font='12px system-ui';
 const y=ms=>top+(150-ms)/300*(bottom-top);
 for(const ms of [-150,-70,0,70,150]){ctx.strokeStyle=ms===0?'#dce7ed':'#3c5161';ctx.beginPath();ctx.moveTo(left,y(ms));ctx.lineTo(right,y(ms));ctx.stroke();ctx.fillStyle='#a8bdc9';ctx.fillText(`${ms}`,3,y(ms)+4);}
 notes.forEach((e,i)=>{const x=left+(i+.5)/Math.max(1,notes.length)*(right-left);ctx.fillStyle=colors[e.result];if(e.error===null){ctx.font='bold 15px system-ui';ctx.fillText('×',x-4,bottom+17);}else{ctx.beginPath();ctx.arc(x,y(Math.max(-150,Math.min(150,e.error))),4,0,7);ctx.fill();}});
 ctx.fillStyle='#a8bdc9';ctx.fillText('Note order →     × = missed onset',left,h-5);
}
let lastNotes=[];
async function sync() {
 $('saveStatus').textContent='Saving…';
 try {$('saveStatus').textContent=await syncResults();}catch(e){$('saveStatus').textContent=`Upload failed; retained on this device. ${e.message}`;}
 if(!localAvailable)$('storageStatus').textContent='Browser storage unavailable; keep this page open to retain results.';
}
function finish(manual) {
 const g=active;if(!g)return;
 const now=audio.currentTime-g.offset/1000;
 // A partial round includes only onsets that actually became playable.
 const notes=g.events.filter(e=>!e.rest && (!manual||e.time<=now));
 notes.forEach(e=>{e.result??='Miss';});active=null;silence();lockControls(false);
 $('phase').textContent=manual?'Practice finished':'Round complete';$('results').hidden=false;lastNotes=notes;
 const errors=notes.filter(e=>e.error!==null).map(e=>e.error), meanAbs=errors.length?errors.reduce((s,e)=>s+Math.abs(e),0)/errors.length:null;
 const signed=errors.length?errors.reduce((s,e)=>s+e,0)/errors.length:null;
 const counts=Object.fromEntries(Object.keys(colors).map(k=>[k,notes.filter(e=>e.result===k).length]));
 $('stats').replaceChildren();
 for(const [label,value] of [['Avg. absolute error',meanAbs===null?'—':`${meanAbs.toFixed(0)} ms`],...Object.entries(counts),['Extra taps',g.extras]]){const item=document.createElement('div'),b=document.createElement('b');b.textContent=value;item.append(b,document.createTextNode(label));$('stats').append(item);}
 $('graphText').textContent=`${notes.length} note onsets. Signed average: ${signed===null?'not available':signed.toFixed(1)+' ms'}. Misses and extra taps are counted separately, not included in the error average.`;graph(notes);
 if(notes.length){saveRecord({id:crypto.randomUUID(),date:new Date().toISOString(),rhythm_type:g.level.type,tempo:g.bpm,average_timing_error:meanAbs,signed_timing_error:signed,note_count:notes.length,miss_count:counts.Miss,extra_taps:g.extras,mode:g.practice?'practice':'round'});sync();}
 else $('saveStatus').textContent='No played notes yet. Start another round.';
}
async function beginCalibration() {
 try {await unlockAudio();}catch(e){$('calStatus').textContent=e.message;return;}
 silence();calibration={start:audio.currentTime+.4,scheduled:0,samples:[],used:new Set()};$('calStart').disabled=true;$('calTap').disabled=false;
}
function calibrationTap(event) {
 const c=calibration,t=inputTime(event),i=Math.round((t-c.start)/.6);
 if(i<4||i>=16||c.used.has(i))return;
 const error=(t-(c.start+i*.6))*1000;if(Math.abs(error)>250)return;
 c.used.add(i);c.samples.push(error);
}
function finishCalibration() {
 const samples=calibration.samples.sort((a,b)=>a-b);calibration=null;silence();$('calStart').disabled=false;$('calTap').disabled=true;
 if(samples.length<6){$('calStatus').textContent='Fewer than 6 usable taps. Try again; listen before tapping.';return;}
 const m=Math.floor(samples.length/2);settings.offset=Math.round(samples.length%2?samples[m]:(samples[m-1]+samples[m])/2);persist();updateSettings();$('calStatus').textContent=`Saved ${settings.offset} ms offset from ${samples.length} taps. Close to practice.`;
}
$('start').onclick=start;$('stop').onclick=()=>finish(true);$('tap').onpointerdown=e=>{e.preventDefault();tap(e);};
$('calibrate').onclick=()=>$('calibration').showModal();$('calStart').onclick=beginCalibration;$('calTap').onpointerdown=e=>{e.preventDefault();tap(e);};
function closeCalibration(){calibration=null;silence();$('calStart').disabled=false;$('calTap').disabled=true;$('calibration').close();}
$('calClose').onclick=closeCalibration;$('calibration').oncancel=closeCalibration;
$('calReset').onclick=()=>{settings.offset=0;persist();updateSettings();$('calStatus').textContent='Offset reset to 0 ms.';};
document.addEventListener('keydown',e=>{if(e.code!=='Space'||e.repeat||['INPUT','SELECT','TEXTAREA'].includes(e.target.tagName))return;if(active||calibration){e.preventDefault();tap(e);}});
// Abort a hidden round instead of reporting false misses from a throttled tab.
document.addEventListener('visibilitychange',()=>{if(document.hidden){if(active)finish(true);if(calibration)closeCalibration();}});
$('url').value=settings.url;$('key').value=settings.key;
$('connect').onclick=()=>{try{const url=new URL($('url').value);if(url.protocol!=='https:'||!url.hostname.endsWith('.supabase.co'))throw new Error('Use your https://PROJECT.supabase.co URL.');const key=$('key').value.trim();if(!key)throw new Error('Enter a publishable or anon key.');let role='';try{role=JSON.parse(atob(key.split('.')[1])).role;}catch{}if(key.startsWith('sb_secret_')||role==='service_role')throw new Error('Use a publishable key, never a secret key.');settings.url=url.origin;settings.key=key;persist();$('connectionStatus').textContent='Connection saved. Uploading pending results…';sync();}catch(e){$('connectionStatus').textContent=e.message;}};
$('retry').onclick=sync;
window.addEventListener('resize',()=>{if(!$('results').hidden)graph(lastNotes);});
function frame(){schedule();drawLane();requestAnimationFrame(frame);}updateSettings();requestAnimationFrame(frame);

````

## supabase.sql

````sql
-- Run once in the Supabase SQL Editor. Each browser signs in anonymously.
create table if not exists public.rhythm_results (
 id uuid primary key,
 user_id uuid not null references auth.users(id) on delete cascade,
 date timestamptz not null default now(),
 rhythm_type text not null,
 tempo integer not null check (tempo between 40 and 180),
 -- Mean absolute error in milliseconds, excluding misses. NULL = no matched taps.
 average_timing_error double precision check (average_timing_error >= 0),
 signed_timing_error double precision,
 note_count integer not null check (note_count > 0),
 miss_count integer not null check (miss_count >= 0),
 extra_taps integer not null check (extra_taps >= 0),
 mode text not null check (mode in ('round','practice'))
);
alter table public.rhythm_results enable row level security;
revoke all on public.rhythm_results from anon;
grant select, insert on public.rhythm_results to authenticated;
create policy "Students insert their own results" on public.rhythm_results
 for insert to authenticated with check ((select auth.uid()) = user_id);
create policy "Students read their own results" on public.rhythm_results
 for select to authenticated using ((select auth.uid()) = user_id);
-- No UPDATE or DELETE policies: client code cannot alter prior results.

````

## package.json

````json
{"name":"rhythm-lab","private":true,"type":"module","scripts":{"test":"node --test tests/*.test.js"}}

````

## tests/rhythm.test.js

````javascript
// Verify musical measure arithmetic and the exact judgment boundaries.
import test from 'node:test';
import assert from 'node:assert/strict';
import {LEVELS,makeMeasure,classify} from '../dist/rhythms.js';
test('every pattern fills its measure with non-overlapping onsets',()=>{
 for(const l of LEVELS)for(let i=0;i<l.patterns.length;i++){
  const notes=makeMeasure(l,i);assert.ok(Math.abs(notes.reduce((s,n)=>s+n.duration,0)-l.bar)<1e-9);
  for(let j=1;j<notes.length;j++)assert.ok(notes[j].beat>notes[j-1].beat);
 }
});
test('timing boundaries preserve sign',()=>{
 for(const [error,result] of [[0,'Perfect'],[-30,'Perfect'],[31,'Good'],[70,'Good'],[-71,'Early'],[71,'Late'],[150,'Late'],[-151,'Miss']])assert.equal(classify(error),result);
});
test('6/8 has two dotted-quarter pulses and six eighth subdivisions',()=>{
 const l=LEVELS.at(-1);assert.equal(l.bar/l.pulse,2);assert.equal(l.bar/l.sub,6);
});

````

## README.md

````markdown
# Rhythm Lab — beginner band rhythm game

All source files are included in full, with comments. No build step or paid library is required.

## Run it on your computer

1. Download and extract the ZIP. Keep the files together.
2. Install Python 3 from https://www.python.org/downloads/ if you do not already have it. On Windows, select “Add Python to PATH.”
3. Open a terminal in the extracted `rhythm-lab` folder. On Windows, open the folder in File Explorer, click the address bar, type `cmd`, and press Enter.
4. Run `python -m http.server 8000 --directory dist`. On macOS, you may need `python3` instead of `python`.
5. Open http://localhost:8000 in Chrome, Edge, Firefox, or Safari. Leave the terminal running. Press Ctrl+C in the terminal to stop the server.

Do not just double-click index.html: JavaScript modules need a web server. No npm install is needed to play. A phone can use the hosted version; local audio features require localhost or HTTPS.

## Play

Choose a level, set 40–180 BPM, and press Start round. Listen through one measure of count-in. Notes move toward the gold hit line. Tap Space or the large Tap rhythm button when each note begins. Pointer-down responds immediately to clicks or touches. Do not hold long notes or tap rests. Repeated keydown events are ignored.

Each round contains four measures. Practice mode repeats the first measure of the chosen level until Finish / stop. Controls lock during play so tempo cannot change the active timeline. Moving to another tab ends the round and reports only elapsed onsets.

In 4/4 and 3/4, BPM means quarter notes. In 6/8, BPM means dotted quarters: two main pulses per measure. The metronome also sounds quieter eighth subdivisions for 6/8. Strong clicks mark bar beginnings. Count-in always sounds even if the round metronome is unchecked.

Perfect is within 30 ms, Good within 70 ms, Early/Late within 150 ms, and unmatched onsets are Misses. At high tempos, dense notes have a matching window smaller than 150 ms (48% of the nearest onset gap) so one tap does not claim a neighboring note. Extra taps are counted separately. Rests are silent; tapping during a rest is an extra tap unless it legitimately matches a nearby note's onset window.

The report graph shows signed milliseconds by note order. Negative = early; positive = late. Misses are × symbols. Average timing error is the mean absolute error of matched taps only; misses and extra taps remain separate so an empty performance cannot appear as 0 ms accuracy. A round with no matched taps saves NULL for average error.

## Calibrate

Press Calibrate timing, then Begin calibration. Listen to four warm-up clicks, then tap with the next twelve clicks at 100 BPM. At least six usable taps are required. The median error becomes the stored offset. Positive offsets are subtracted from input times and used to align the visual lane. Use the same input method and headphones afterward; recalibrate after changing equipment. This measures combined output/input delay and your tapping response, rather than isolating hardware latency. Natural timing bias can influence it.

## Connect Supabase

1. Create a project at https://supabase.com.
2. Open its SQL Editor. Paste the complete contents of `supabase.sql` and run it once.
3. In Authentication settings, enable anonymous sign-ins. Supabase anonymous users are authenticated identities, so each browser can insert and read only rows with its own user ID.
4. Copy your Project URL and **publishable key** (or legacy anon key) from the project API settings. Never use a secret or service-role key in this browser app.
5. Open “Connect Supabase” in the game, paste those values, and press Save connection. Pending results upload automatically. Later rounds save automatically. Use Retry saving results if your connection fails.
6. Inspect `rhythm_results` in the Table Editor. Columns include date, rhythm_type, tempo, average_timing_error (milliseconds), signed_timing_error, note_count, miss_count, extra_taps, and mode.

The app uses Supabase Auth and REST through fetch, with no CDN dependency. Anonymous sessions and results stay in this browser's local storage. Clearing browser data loses this device's identity and local queue. Previously uploaded rows remain in Supabase. Requests use a UUID and ignore-duplicates so retrying does not create duplicate rows. No real student names or email addresses are collected. For a public classroom deployment, configure Supabase's anonymous sign-in abuse controls/rate limits.

Without configured credentials, the game saves locally and labels the result accordingly. Failed uploads remain queued and display an error. Cloud writes cannot be verified until a real project is connected.

## How the code works

- `dist/index.html`: semantic page, settings, canvas, report, and calibration dialog.
- `dist/styles.css`: responsive studio layout and focus styles.
- `dist/rhythms.js`: eight levels, musical durations, and judgment thresholds.
- `dist/app.js`: audio scheduling, scrolling, input matching, calibration, and reports.
- `dist/storage.js`: local persistence, anonymous authentication, and Supabase uploads.
- `supabase.sql`: table and row-level security policies.
- `tests/rhythm.test.js`: musical arithmetic and timing boundary tests.
- `package.json`: optional test command; not needed to run the game.

The Web Audio API `currentTime` is the musical clock. Oscillator clicks are scheduled ahead with oscillator.start(time). requestAnimationFrame replenishes a 200 ms look-ahead queue and renders notes; no setTimeout controls musical timing. Input event timestamps are mapped to the audio clock to account for event dispatch delay. A background tab is stopped to avoid false misses. Severe foreground main-thread stalls can still disrupt the scheduling queue; browser timing is not a laboratory measurement.

To run automated unit checks, install Node.js and run `npm test` from the project folder. No npm install is required.

## Extend it for your engineering portfolio

Add new patterns in rhythms.js, ensuring each measure sums to its bar length. Explain your timing decisions, test results, and calibration limitations in your project write-up. You can compare performance at different tempos using the saved table. Build on the project and be clear about which parts you wrote or adapted.

````

